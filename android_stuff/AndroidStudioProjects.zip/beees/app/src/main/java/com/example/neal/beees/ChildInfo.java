package com.example.neal.beees;


public class ChildInfo {

    private String sequence = "bleep";
    private String name = "bloop";

    public String getSequence() {
        return sequence;
    }

    public void setSequence(String sequence) {
        this.sequence = sequence;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

}