package com.example.neal.beees;
//package example.abhiandroid.expandablelistviewexample;

        import java.util.ArrayList;

public class GroupInfo {

    public String name;
    public ArrayList<ChildInfo> list = new ArrayList<ChildInfo>();

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public ArrayList<ChildInfo> getProductList() {
        return list;
    }

    public void setProductList(ArrayList<ChildInfo> productList) {
        this.list = productList;
    }

}